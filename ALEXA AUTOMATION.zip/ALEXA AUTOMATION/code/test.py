tuple=()
print( tuple)